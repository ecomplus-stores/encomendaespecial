// Add your custom JavaScript for storefront pages here.
/* if (window.innerWidth > 768) {
    $('#mobile-search-btn').on('click', () => {
        $('#search-input').trigger('focus')
    })
} */

window.$ecomConfig.set('default_img_size', 'zoom')